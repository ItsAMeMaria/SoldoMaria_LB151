from django.shortcuts import redirect, render
from django.http import HttpResponse
from .models import Player
# Create your views here.
def index(request):
    return render(request, "index.html")

def game(request):
    return render(request, "game.html")

def admin(request):
    return render(request, "admin.html")

def add_player(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        player = Player(name=name)
        player.save()
        return redirect('players')
    else:
        return render(request, 'add_player.html')